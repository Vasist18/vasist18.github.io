# Vasist Kuntapalli — Portfolio

A responsive static portfolio website built with HTML/CSS/JavaScript.

## Publish with GitHub Pages

1. Create a **public** repository named `vasist18.github.io` in the GitHub account `Vasist18`.
2. Upload `index.html`, `resume.pdf`, and this `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/(root)`, then Save.
5. Wait for the deployment to finish. The expected URL is `https://vasist18.github.io/`.

GitHub's official instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

Note: the URL is not live until the repository is created and GitHub Pages is enabled. This package does not publish to your account automatically.
